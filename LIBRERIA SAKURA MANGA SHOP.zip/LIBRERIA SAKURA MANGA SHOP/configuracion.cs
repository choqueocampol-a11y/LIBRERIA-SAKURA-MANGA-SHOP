﻿using System;
using System.Windows.Forms;
using Libreria_Datos;
using Libreria_Negocio;

namespace LIBRERIA_SAKURA_MANGA_SHOP
{
    public partial class configuracion : Form
    {
        private readonly UsuarioNegocio _usuarioNegocio = new UsuarioNegocio();
        private int _idUsuarioSeleccionado = 0;
        private readonly RolNegocio _rolNegocio = new RolNegocio();
        public configuracion()
        {
            InitializeComponent();
        }

        private void configuracion_Load(object sender, EventArgs e)
        {
            CargarUsuarios();
            CargarRoles();
        }
        private void CargarRoles()
        {
            try
            {
                var roles = _rolNegocio.ListarRoles();

                // --- PRUEBA DE DEPURACIÓN ---
                if (roles == null || roles.Count == 0)
                {
                    MessageBox.Show("La lista de roles está vacía o es nula.");
                    return;
                }
                else
                {
                    MessageBox.Show($"Se cargaron {roles.Count} roles. Ejemplo: {roles[0].Nombre_Rol}");
                }
                // ---------------------------

                comboBoxRol.DataSource = null; // Resetear antes de asignar
                comboBoxRol.DataSource = roles;
                comboBoxRol.DisplayMember = "Nombre_Rol";
                comboBoxRol.ValueMember = "ID_Rol";
                comboBoxRol.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar roles: " + ex.Message);
            }
        }
        private void CargarUsuarios()
        {
            try
            {
                var usuarios = _usuarioNegocio.ListarUsuarios();
                MostrarUsuariosEnGrid(usuarios);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar usuarios: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MostrarUsuariosEnGrid(System.Collections.Generic.List<UsuarioModel> usuarios)
        {
            // Implementar según el diseño del DataGridView
            // dataGridView1.DataSource = usuarios;
        }

        private void textBoxNombre_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBoxUsername_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBoxPassword_TextChanged(object sender, EventArgs e)
        {
        }

        private void comboBoxRol_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void buttonRegistrar_Click(object sender, EventArgs e)
        {
            if (comboBoxRol.SelectedValue == null)
            {
                MessageBox.Show("Por favor, selecciona un rol válido.");
                return;
            }

            if (ValidarCampos())
            {
                try
                {
                    var nuevoUsuario = new UsuarioModel
                    {
                        Nombre = textBoxNombre.Text.Trim(),
                        Username = textBoxUsername.Text.Trim(),
                        Password = textBoxPassword.Text,
                        // 2. Aquí está la clave: asignar el ID del rol seleccionado
                        ID_Rol = Convert.ToInt32(comboBoxRol.SelectedValue)
                    };

                    _usuarioNegocio.RegistrarUsuario(nuevoUsuario);
                    // ... resto del código
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al registrar: " + ex.Message);
                }
            }
        }

        private void buttonModificar_Click(object sender, EventArgs e)
        {
            if (_idUsuarioSeleccionado == 0)
            {
                MessageBox.Show("Selecciona un usuario para modificar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (ValidarCampos())
            {
                try
                {
                    var usuarioModificado = new UsuarioModel
                    {
                        ID_Usuario = _idUsuarioSeleccionado,
                        Nombre = textBoxNombre.Text.Trim(),
                        Username = textBoxUsername.Text.Trim()
                    };

                    _usuarioNegocio.ModificarUsuario(usuarioModificado);
                    MessageBox.Show("Usuario modificado correctamente 🌸", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LimpiarFormulario();
                    CargarUsuarios();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al modificar: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void buttonEliminar_Click(object sender, EventArgs e)
        {
            if (_idUsuarioSeleccionado == 0)
            {
                MessageBox.Show("Selecciona un usuario para eliminar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult resultado = MessageBox.Show("¿Estás seguro de que deseas eliminar este usuario?", "Confirmar eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                try
                {
                    _usuarioNegocio.EliminarUsuario(_idUsuarioSeleccionado);
                    MessageBox.Show("Usuario eliminado correctamente 🌸", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LimpiarFormulario();
                    CargarUsuarios();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al eliminar: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void buttonLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarFormulario();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
        }

        private void textBoxBuscar_TextChanged(object sender, EventArgs e)
        {
        }

        private void buttonBuscar_Click(object sender, EventArgs e)
        {
            // Implementar búsqueda según necesidad
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Cargar datos del usuario seleccionado
        }

        private void LimpiarFormulario()
        {
            textBoxNombre.Clear();
            textBoxUsername.Clear();
            textBoxPassword.Clear();
            _idUsuarioSeleccionado = 0;
        }

        private bool ValidarCampos()
        {
            if (string.IsNullOrWhiteSpace(textBoxNombre.Text))
            {
                MessageBox.Show("El nombre no puede estar vacío.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(textBoxUsername.Text))
            {
                MessageBox.Show("El nombre de usuario no puede estar vacío.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(textBoxPassword.Text) && _idUsuarioSeleccionado == 0)
            {
                MessageBox.Show("La contraseña no puede estar vacía para nuevos usuarios.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }
    }
}